class MyClass7
{
	public static void main(String args[])
	{
		System.out.println("hello world");
	}
}	
public class MyClass8
{

}






















