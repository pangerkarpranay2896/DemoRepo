class MyClass5
{
	public static void main(String args[])
	{
		System.out.println("hello world");
	}
}	
class MyClass6
{

}






















