package core1;
public class Test6
{
	static void disp(Long x)
	{
		System.out.println("in Long");
	}
	public static void main(String args[])
	{

		byte a=3;
		disp(a);
	}
}
		

// compiler error