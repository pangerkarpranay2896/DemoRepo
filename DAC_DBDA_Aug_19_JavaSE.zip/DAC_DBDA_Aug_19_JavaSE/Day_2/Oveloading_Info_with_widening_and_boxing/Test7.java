package core1;
public class Test7
{
	static void disp(Object o)
	{
	System.out.println("in Object");
	}
	public static void main(String args[])
	{
		byte b=4;
		disp(b);
	}
}


/*

compiler can do boxing followed by widening operation

*/		