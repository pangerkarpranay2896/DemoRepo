package datatypes_pro;

public class Do_While_Demo
{
	public static void main(String[] args)
	{
		int a=10;
		// Post-Test Loop
		do
		{
			System.out.println(a);
			a++;
		}while(a<20);
	}
}
