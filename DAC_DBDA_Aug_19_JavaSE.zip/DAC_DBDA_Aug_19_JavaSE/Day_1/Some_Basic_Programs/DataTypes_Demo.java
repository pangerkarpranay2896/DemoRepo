package datatypes_pro;

public class Datatypes_Demo
{
	public static void main(String[] args)
	{
		// integral types
		byte a=10;
		short b=20;
		int c=30;
		long d=40;
		System.out.println(a+"\t"+b+"\t"+c+"\t"+d);
		
		// floating point
		float e=3.5f;
		double f=5.6;
		System.out.println(e+"\t"+f);
		// character
		char g='A';
		// boolean
		System.out.println(g);
		boolean h=true;
		System.out.println(h);
		// reference types
		String i="hello";
		System.out.println(i);
	}
}
