package datatypes_pro;

public class While_Demo
{
	public static void main(String[] args)
	{
		int a=10;
		// Pre-Test Loop
		while(a<20)
		{
			System.out.println(a);
			a++;
		}
	}
}
