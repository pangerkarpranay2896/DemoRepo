package datatypes_pro;

public class For_Demo_3
{
	public static void main(String[] args)
	{
		int i;
		for(i=0;i<5;i++)
		{
			if(i==3)
			{
				continue;
			}
			System.out.println(i);
		}
	}
}
