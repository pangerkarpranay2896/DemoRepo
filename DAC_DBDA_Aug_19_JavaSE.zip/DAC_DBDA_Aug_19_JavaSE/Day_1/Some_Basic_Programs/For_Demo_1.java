package datatypes_pro;

public class For_Demo_1
{
	public static void main(String[] args)
	{
		int i;
		for(i=0;i<5;i++)
		{
			System.out.println(i);
		}
	}
}
