package datatypes_pro;

public class If_Demo
{
	public static void main(String[] args)
	{
		int a=10;
		if(a>0)
		{
			System.out.println("it's positive");
		}
		else if(a<0)
		{
			System.out.println("it's negative");
		}
		else
		{
			System.out.println("it's negative");
		}
	}
}
