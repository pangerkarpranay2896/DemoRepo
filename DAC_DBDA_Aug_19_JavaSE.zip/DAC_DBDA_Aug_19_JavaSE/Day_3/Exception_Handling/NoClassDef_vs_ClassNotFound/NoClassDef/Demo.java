class Y
{

}

class Z
{

}
public class Demo
{
	static Y ref=new Y();
	public static void main(String args[])
	{
		System.out.println("in main");
		Z ref1=new Z();
	}
}
