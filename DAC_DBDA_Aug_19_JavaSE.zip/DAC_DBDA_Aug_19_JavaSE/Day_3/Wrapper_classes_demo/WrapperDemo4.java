public class WrapperDemo4
{
	public static void main(String args[])
	{
		String str=" 125 ";
		int k=Integer.parseInt(str.trim());
		k+=10;
		System.out.println(k);
	}
}
	