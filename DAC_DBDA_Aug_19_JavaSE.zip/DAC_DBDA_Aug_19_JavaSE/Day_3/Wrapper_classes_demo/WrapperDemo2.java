public class WrapperDemo2
{
	public static void main(String args[])
	{
		String str="125";
		str+=10;
		System.out.println(str);
	}
}
	