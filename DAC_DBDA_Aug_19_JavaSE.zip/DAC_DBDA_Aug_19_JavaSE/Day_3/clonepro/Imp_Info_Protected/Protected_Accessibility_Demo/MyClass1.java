package trial;

public class MyClass1 {
	protected void disp()
	{
		System.out.println("inside MyClass1 disp");
	}
}
