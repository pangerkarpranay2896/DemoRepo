
public class MyClass10
{
	static
	{
		System.out.println("in MyClass10 first static initializer");
	}
	public static void main(String args[])
	{
		System.out.println("in main");		
	}
	
	static
	{
		System.out.println("in MyClass10 second static initializer");
	}

}