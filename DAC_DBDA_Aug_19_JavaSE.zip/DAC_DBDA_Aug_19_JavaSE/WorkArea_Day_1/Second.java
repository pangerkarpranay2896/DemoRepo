public class Second
{
	//int num=10; // instance member
	int num;
	public static void main(String args[])
	{
		int var=20; // local member
		//int var; 
		System.out.println(var);
		Second s1=new Second();
		System.out.println(s1.num);
		
	}
}